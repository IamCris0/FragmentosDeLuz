"""Voces de la fase 6 con Piper TTS (offline) y procesado de estudio con Pedalboard.

Uso:  python source_tools/build_voices.py [id ...]
Requisitos: pip install piper-tts pedalboard soundfile pyloudnorm numpy scipy
Modelos:
  Luma  -> Coqui TTS Tacotron2-DDC español (M-AILABS, voz femenina) + vocoder MelGAN, MPL 2.0.
           Se ejecuta con el Python de Coqui indicado en FDL_COQUI_PYTHON y los modelos en FDL_COQUI_MODELS
           (ver coqui_synth.py). El modelo Piper mls_10246 se descartó: repetía y alargaba frases.
  Neri y el cronista -> Piper voice-es-carlfm-x-low (dominio público), GitHub rhasspy/piper v0.0.2,
           en source_assets/voices/ o en la variable FDL_VOICES.
Salida: godot/assets/audio/voice/<id>.ogg  (id = "vo_" + id de la historia o de la cinemática)

Luma suena como un espíritu: coro suave, un armónico brillante muy bajo y reverberación.
Neri se sube dos semitonos para rejuvenecer la voz base. El cronista baja tres y resuena en sala.
"""
import os
import subprocess
import sys
import tempfile

import numpy as np
import soundfile
from pedalboard import (Chorus, Compressor, Delay, HighpassFilter, HighShelfFilter, LowShelfFilter, Pedalboard,
                        PitchShift, Reverb)
from scipy.signal import resample_poly

sys.path.insert(0, os.path.dirname(__file__))
from music_lib import RATE, normalize, write_ogg  # noqa: E402

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT = os.path.join(ROOT, "godot", "assets", "audio", "voice")
VOICE_DIRS = [os.environ.get("FDL_VOICES", ""), os.path.join(ROOT, "source_assets", "voices"), "/home/claude/tts"]
PIPER = os.environ.get("FDL_PIPER", "piper")
COQUI_PYTHON = os.environ.get("FDL_COQUI_PYTHON", "/home/claude/coquienv/bin/python")
COQUI_MODELS = os.environ.get("FDL_COQUI_MODELS", "/home/claude/coqui")

MODELS = {
    "luma": ("voice-es-mls_10246-low", "es-mls_10246-low.onnx", 1.06, 0.5),
    "neri": ("voice-es-carlfm-x-low", "es-carlfm-x-low.onnx", 1.14, 0.55),
    "cronista": ("voice-es-carlfm-x-low", "es-carlfm-x-low.onnx", 1.2, 0.5),
}

LINES = {
    # Prólogo (narración por viñeta; coincide con los textos en pantalla).
    "vo_prologue_0": ("cronista", "Antes de la tormenta, el faro mantenía unidas las islas suspendidas."),
    "vo_prologue_1": ("cronista", "Una señal imposible partió el núcleo en siete fragmentos de luz."),
    "vo_prologue_2": ("cronista", "Años después, Neri encuentra el eco perdido en su escáner."),
    "vo_prologue_3": ("cronista", "En las ruinas espera Luma, y con ella, la última ruta hacia el faro."),
    # Diálogos del capítulo (story ids).
    "vo_arrival": ("neri", "La señal de mi escáner termina aquí. Islas que no deberían flotar. Un faro que no debería "
                           "seguir encendido. Hay ecos moviéndose entre las ruinas. Si el escáner responde, quizás "
                           "pueda empujarlos con una descarga de luz."),
    "vo_luma_intro": ("luma", "Llegaste siguiendo una señal, Neri. Yo llevo cien años esperando una respuesta. Cuando "
                              "el faro se apagó, nuestra ciudad se partió en el cielo. No todo lo que quedó aquí quiere "
                              "volver a despertar. Los ecos del faro se alimentan de energía viva: si se acercan "
                              "demasiado, usa tu pulso de luz. Recupera los siete fragmentos de su núcleo. En el jardín, "
                              "despierta primero la ola, después el sol, y al final la estrella. El puente recordará el "
                              "camino."),
    "vo_garden_hint": ("luma", "El agua recuerda. El sol despierta. La estrella guía. Ola, sol, estrella. Una nota fuera "
                               "de lugar devuelve el jardín al silencio."),
    "vo_relic": ("cronista", "Quien encuentre esta reliquia: no reconstruya nuestros muros. Encienda el faro, para que "
                             "los que aún flotan lejos puedan volver a casa. El consejo de Auralia."),
    "vo_ending": ("luma", "Los fragmentos se elevan de tu escáner, y el cielo responde. Una luz tras otra aparece en las "
                          "islas distantes. No has devuelto la ciudad al pasado. Le has dado un mañana."),
    # Memorias de Auralia (coleccionables de la fase 6).
    "vo_lore_1": ("luma", "Los faroleros de Auralia cantaban al encender la luz. Decían que el faro no iluminaba el camino: lo recordaba."),
    "vo_lore_2": ("luma", "Aquí crecían jardines que sonaban con el viento. Cada flor guardaba una nota, y cada nota, un nombre."),
    "vo_lore_3": ("luma", "Los engranajes no movían piedras: movían mareas de luz. Cuando se detuvieron, las islas empezaron a alejarse unas de otras."),
    "vo_lore_4": ("luma", "Desde el Paso del Cielo, los viajeros veían otras islas brillar como faroles lejanos. Esperaban una señal para volver."),
    "vo_lore_5": ("luma", "La noche de la fractura, alguien envió una señal imposible desde el faro. Nadie supo quién. Luma nunca dejó de escucharla."),
    # Cinemáticas.
    "vo_cine_arrival_1": ("luma", "Siete fragmentos. Un faro dormido desde hace cien años."),
    "vo_cine_arrival_2": ("luma", "Y, por fin, alguien ha escuchado la señal."),
    "vo_cine_garden_1": ("luma", "El jardín recuerda su melodía."),
    "vo_cine_garden_2": ("luma", "El camino al Paso del Cielo está abierto."),
    "vo_cine_guardian_1": ("luma", "Ese eco nació del núcleo roto. Interrumpe su carga con tu pulso de luz."),
    "vo_cine_finale_1": ("luma", "Los siete fragmentos vuelven a casa."),
    "vo_cine_finale_2": ("luma", "El faro vuelve a cantar."),
    "vo_cine_finale_3": ("luma", "Una luz tras otra, las islas lejanas responden."),
    "vo_cine_finale_4": ("luma", "No has devuelto la ciudad al pasado, Neri. Le has dado un mañana."),
    "vo_cine_finale_5": ("neri", "Alguien más vio la señal. Vamos, Luma."),
}


def model_path(folder: str, filename: str) -> str:
    for base in VOICE_DIRS:
        if base and os.path.exists(os.path.join(base, folder, filename)):
            return os.path.join(base, folder, filename)
    raise FileNotFoundError(f"Falta el modelo {folder}/{filename}")


def synthesize(voice: str, text: str, work: str) -> np.ndarray:
    wav = os.path.join(work, "line.wav")
    if voice == "luma":
        subprocess.run([COQUI_PYTHON, os.path.join(os.path.dirname(__file__), "coqui_synth.py"), COQUI_MODELS, text, wav],
                       check=True, capture_output=True)
        audio, rate = soundfile.read(wav, dtype="float32")
        audio = resample_poly(audio, RATE, rate).astype(np.float32)
        return np.stack([audio, audio], axis=0)
    folder, filename, length, noise = MODELS[voice]
    subprocess.run([PIPER, "-m", model_path(folder, filename), "-f", wav, "--length-scale", str(length),
                    "--noise-scale", str(noise), "--noise-w-scale", "0.6", "--sentence-silence", "0.38"],
                   input=text.encode("utf-8"), check=True, capture_output=True)
    audio, rate = soundfile.read(wav, dtype="float32")
    audio = resample_poly(audio, RATE, rate).astype(np.float32)
    return np.stack([audio, audio], axis=0)


def process(voice: str, audio: np.ndarray) -> np.ndarray:
    lead = np.zeros((2, int(0.08 * RATE)), dtype=np.float32)
    tail = np.zeros((2, int(1.1 * RATE)), dtype=np.float32)
    audio = np.concatenate([lead, audio, tail], axis=1)
    if voice == "luma":
        body = Pedalboard([PitchShift(1.0), HighpassFilter(110), LowShelfFilter(250, -2.0), HighShelfFilter(4200, 2.0),
                           Compressor(-22, 2.5, 8, 120)])(audio, RATE)
        shimmer = Pedalboard([PitchShift(12), HighpassFilter(1800)])(body, RATE) * 0.07
        mixed = Pedalboard([Chorus(rate_hz=0.6, depth=0.18, centre_delay_ms=9, feedback=0.1, mix=0.3),
                            Delay(delay_seconds=0.19, feedback=0.15, mix=0.07),
                            Reverb(room_size=0.6, damping=0.5, wet_level=0.2, dry_level=0.86, width=0.9)])(body + shimmer, RATE)
    elif voice == "neri":
        mixed = Pedalboard([PitchShift(2.0), HighpassFilter(95), LowShelfFilter(220, -1.5), HighShelfFilter(4000, 2.0),
                            Compressor(-20, 2.5, 6, 120),
                            Reverb(room_size=0.28, damping=0.6, wet_level=0.08, dry_level=0.95, width=0.6)])(audio, RATE)
    else:
        mixed = Pedalboard([PitchShift(-3.0), HighpassFilter(70), LowShelfFilter(200, 2.0), HighShelfFilter(5000, -1.5),
                            Compressor(-22, 2.5, 8, 150),
                            Reverb(room_size=0.72, damping=0.55, wet_level=0.2, dry_level=0.85, width=1.0)])(audio, RATE)
    mixed = mixed.T
    # Recorta el silencio final dejando la cola de reverberación.
    energy = np.abs(mixed).max(axis=1)
    last = np.nonzero(energy > 0.002)[0]
    end = min(len(mixed), (last[-1] if len(last) else len(mixed)) + int(0.25 * RATE))
    return mixed[:end]


def main(ids: list[str]) -> None:
    os.makedirs(OUT, exist_ok=True)
    with tempfile.TemporaryDirectory() as work:
        for key in ids or list(LINES):
            voice, text = LINES[key]
            audio = process(voice, synthesize(voice, text, work))
            audio = normalize(audio, -19.0, ceiling_db=-1.0)
            write_ogg(audio, os.path.join(OUT, key + ".ogg"), quality=4)
            print("VOICE", key, voice, round(len(audio) / RATE, 2))


if __name__ == "__main__":
    main(sys.argv[1:])
