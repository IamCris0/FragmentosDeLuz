extends RefCounted
## Texto de los créditos finales y del menú. Edita este archivo para poner tu nombre o tu estudio.

const STUDIO := "Equipo de Fragmentos de Luz"

const EPILOGUE := [
	"Los fragmentos se elevaron del escáner y el cielo respondió.",
	"Una luz tras otra apareció en las islas distantes.",
	"«No has devuelto la ciudad al pasado. Le has dado un mañana.»",
	"Neri cruzó el umbral. Al otro lado, alguien había visto la señal.",
]

const SECTIONS := [
	["FRAGMENTOS DE LUZ", ["Capítulo I · El Faro Dormido"]],
	["Creación y dirección", [STUDIO]],
	["Dirección de arte y referencias", ["Miora · hojas de personaje, isla, zonas y props"]],
	["Personaje de Neri", ["Base y animaciones: Quaternius (CC0)", "Universal Base Characters · Universal Animation Library", "Adaptación y vestuario en Blender"]],
	["Luma, archivista de Auralia", ["Modelado procedural en Blender", "Animación procedural en Godot"]],
	["Mundo y efectos", ["Generadores de Blender y Godot del proyecto", "Shaders de portal, faro, cascadas, viento y espíritu"]],
	["Música original", ["Compuesta por procedimientos (MIDI)", "Interpretada con el banco FluidR3 GM (licencia MIT)"]],
	["Voces sintetizadas", ["Luma: Coqui TTS · Tacotron2-DDC español (MPL 2.0), corpus M-AILABS", "Neri y el cronista: Piper TTS (MIT) · voz carlfm (dominio público)"]],
	["Tipografías", ["Cinzel y Cinzel Decorative · Nunito (SIL Open Font License)"]],
	["Motor", ["Godot Engine 4.7 · Blender 5"]],
	["Gracias por jugar", ["La historia de Auralia continuará."]],
]
