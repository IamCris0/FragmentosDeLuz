extends Node

var music: AudioStreamPlayer
var wind: AudioStreamPlayer
var voices: Array[AudioStreamPlayer] = []
var cues: Dictionary = {}
var next_voice: int = 0
var themes: Array[AudioStreamPlayer] = []
var target_theme: int = 0
var ducked: bool = false
var tension: AudioStreamPlayer


func loop_stream(path: String) -> AudioStreamWAV:
	var stream: AudioStreamWAV=load(path).duplicate()
	stream.loop_mode=AudioStreamWAV.LOOP_FORWARD
	stream.loop_begin=0
	stream.loop_end=int(stream.get_length()*stream.mix_rate)
	return stream


func _ready() -> void:
	for cue in ["step", "jump", "pickup", "rune", "wrong", "solved", "lever", "chest", "portal", "story", "respawn", "land", "pulse", "hit", "enemy_hit", "enemy_alert", "step_0", "step_1", "step_2", "step_3", "dodge", "guardian_charge", "guardian_wave", "beacon_chime"]:
		cues[cue] = load("res://assets/audio/%s.wav" % cue)
	for i in range(8):
		var voice := AudioStreamPlayer.new()
		voice.name = "Effect_%d" % i
		voice.volume_db = -10
		voice.bus="Effects"
		add_child(voice)
		voices.append(voice)
	for theme in ["music_exploration","music_garden","music_sanctuary"]:
		var layer:=AudioStreamPlayer.new()
		layer.name=theme
		layer.stream=loop_stream("res://assets/audio/%s.wav"%theme)
		layer.bus="Music"
		layer.volume_db=-50.
		add_child(layer)
		layer.play()
		themes.append(layer)
	music=themes[0]
	tension = AudioStreamPlayer.new()
	tension.name = "CombatTension"
	tension.stream = loop_stream("res://assets/audio/combat_tension.wav")
	tension.bus = "Music"
	tension.volume_db = -60
	add_child(tension)
	tension.play()
	wind = AudioStreamPlayer.new()
	wind.name = "Wind"
	wind.stream = loop_stream("res://assets/audio/wind_soft.wav")
	wind.bus="Ambience"
	wind.volume_db = -14
	add_child(wind)
	wind.play()
	GameEvents.sound_requested.connect(play_cue)
	GameEvents.zone_changed.connect(func(index: int, _title: String) -> void: target_theme=1 if index==1 else (2 if index==3 else 0))
	for point in [Vector3(10,0,-5),Vector3(-9,0,-36),Vector3(9,4,-90)]:
		spatial_loop("WaterfallAudio",point,"waterfall",-14.,20.)
	spatial_loop("PortalHum",Vector3(0,6,-90),"crystal_hum",-5.,12.)


func spatial_loop(title: String, point: Vector3, cue: String, gain: float, distance: float) -> void:
	var source:=AudioStreamPlayer3D.new()
	source.name=title
	source.position=point
	source.stream=loop_stream("res://assets/audio/%s.wav"%cue)
	source.bus="Ambience"
	source.volume_db=gain
	source.unit_size=5.
	source.max_distance=distance
	add_child(source,true)
	source.play()


func _process(delta: float) -> void:
	var hud: Node=get_parent().get_node("HUDLayer")
	ducked=hud.dialog_open
	var tension_gain: float = -60.0 if ducked or GameEvents.active_threats == 0 else (-13.0 if GameEvents.zone == 3 else -21.0)
	tension.volume_db = lerpf(tension.volume_db, tension_gain, 1.0 - exp(-delta * 2.5))
	for i in themes.size():
		var target: float=(-7. if ducked else -1.) if i==target_theme else -55.
		themes[i].volume_db=lerpf(themes[i].volume_db,target,1.-exp(-delta*.8))


func play_cue(cue: String) -> void:
	var is_step: bool=cue=="step"
	if is_step:cue="step_%d"%randi_range(0,3)
	if not cues.has(cue): return
	var voice: AudioStreamPlayer = voices[next_voice]
	next_voice = (next_voice + 1) % voices.size()
	voice.stream = cues[cue]
	voice.volume_db = -17 if is_step else -9
	voice.pitch_scale = randf_range(0.94,1.06) if is_step else 1.0
	voice.play()
