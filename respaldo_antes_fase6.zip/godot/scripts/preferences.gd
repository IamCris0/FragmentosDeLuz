extends Node

signal quality_changed(level: int)
const PATH: String = "user://preferences.cfg"
var volumes: Dictionary = {"Master": .8, "Music": .7, "Ambience": .65, "Effects": .85}
var quality: int = 1


func _ready() -> void:
	for bus in ["Music","Ambience","Effects"]:
		if AudioServer.get_bus_index(bus)<0:
			AudioServer.add_bus()
			var index: int=AudioServer.bus_count-1
			AudioServer.set_bus_name(index,bus)
			AudioServer.set_bus_send(index,"Master")
	var config:=ConfigFile.new()
	if not "--qa" in OS.get_cmdline_user_args() and config.load(PATH)==OK:
		for bus in volumes: volumes[bus]=clampf(float(config.get_value("audio",bus,volumes[bus])),0.,1.)
		quality=clampi(int(config.get_value("graphics","quality",1)),0,2)
	for bus in volumes: apply_volume(bus)


func apply_volume(bus: String) -> void:
	var index: int=AudioServer.get_bus_index(bus)
	AudioServer.set_bus_volume_db(index,linear_to_db(maxf(float(volumes[bus]),.0001)))
	AudioServer.set_bus_mute(index,float(volumes[bus])<=0)


func set_volume(bus: String, value: float) -> void:
	volumes[bus]=clampf(value,0.,1.)
	apply_volume(bus)
	save()


func set_quality(value: int) -> void:
	quality=clampi(value,0,2)
	quality_changed.emit(quality)
	save()


func save() -> void:
	if "--qa" in OS.get_cmdline_user_args():return
	var config:=ConfigFile.new()
	for bus in volumes:config.set_value("audio",bus,volumes[bus])
	config.set_value("graphics","quality",quality)
	config.save(PATH)
