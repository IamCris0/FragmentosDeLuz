extends Node3D

const TITLES: Array[String] = ["UMBRAL DE AURALIA", "JARDÍN DE ECOS", "PASO DEL CIELO", "FARO DE AURALIA"]
const ORDER: Array[int] = [1, 0, 2]
var rune_progress: int = 0
var entered_zone: int = -1
var pulse: float = 0
var threat_clock: float = 0.0
@onready var player: CharacterBody3D = $Player
@onready var hud: CanvasLayer = $HUDLayer
@onready var gate: StaticBody3D = $Zones/Puzzle/PuzzleGate


func _enter_tree() -> void:
	GameEvents.load_game()


func _ready() -> void:
	var feedback := Node3D.new()
	feedback.name = "CombatFeedback"
	feedback.set_script(load("res://scripts/combat_feedback.gd"))
	add_child(feedback)
	var beacon := Node3D.new()
	beacon.name = "BeaconRestoration"
	beacon.set_script(load("res://scripts/beacon_restoration.gd"))
	add_child(beacon)
	hud.player = player
	player.global_position = GameEvents.checkpoint
	GameEvents.fragments_changed.emit(GameEvents.collected, 7)
	GameEvents.energy_changed.emit(GameEvents.energy, 100)
	GameEvents.objective_changed.emit(GameEvents.objective)
	GameEvents.tutorial_changed.emit(GameEvents.tutorial_stage, GameEvents.tutorial_text)
	_refresh_gate()
	if GameEvents.completed:
		GameEvents.set_objective("Auralia vuelve a brillar")
	if "--qa" in OS.get_cmdline_user_args():
		var qa:Node=load("res://tools/qa_adventure.gd").new()
		add_child(qa)
		qa.run.call_deferred(self)
	elif not GameEvents.story_seen.has("arrival"):
		await get_tree().create_timer(0.8).timeout
		GameEvents.story("arrival", "NERI · EL FARO DORMIDO", "La señal de mi escáner termina aquí. Islas que no deberían flotar. Un faro que no debería seguir encendido.\n\nHay ecos moviéndose entre las ruinas. Si el escáner responde, quizás pueda empujarlos con una descarga de luz.")


func _process(delta: float) -> void:
	pulse += delta
	threat_clock -= delta
	if threat_clock <= 0.0:
		threat_clock = 0.15
		var count: int = 0
		for enemy in get_tree().get_nodes_in_group("enemy"):
			if enemy.is_threat(): count += 1
		GameEvents.set_threat(count)
	var z: float = player.global_position.z
	var zone: int = 0 if z > -20 else (1 if z > -43 else (2 if z > -75 else 3))
	if zone != entered_zone:
		entered_zone = zone
		GameEvents.zone = zone
		GameEvents.zone_changed.emit(zone, TITLES[zone])
		if zone == 0: GameEvents.checkpoint = Vector3(0,0.2,7)
		elif zone == 1: GameEvents.checkpoint = Vector3(0,0.2,-24)
		elif zone == 2 and player.global_position.y > 3: GameEvents.checkpoint = Vector3(0,4.2,-54)
		elif zone == 3: GameEvents.checkpoint = Vector3(0,4.2,-79)
		if zone == 1 and not GameEvents.puzzle_solved: GameEvents.set_objective("Restaura la melodía de las tres runas")
		elif zone == 2: GameEvents.set_objective("Explora el Paso del Cielo y recupera sus fragmentos")
		elif zone == 3 and not GameEvents.completed: GameEvents.set_objective("Reúne los siete fragmentos y activa el faro")
		GameEvents.save_game()
	if zone == 2 and player.global_position.y > 3.7 and z < -53 and GameEvents.checkpoint.z > -40:
		GameEvents.checkpoint = Vector3(0,4.2,-54)
		GameEvents.save_game()
	var vortex: ShaderMaterial = $Zones/PortalFinal/Portal/Vortex.material_override
	vortex.set_shader_parameter("active", GameEvents.collected == 7 and GameEvents.puzzle_solved and (GameEvents.completed or GameEvents.purified_ids.has("BeaconEcho")))
	$Zones/Entrance/Luma/Visual.position.y = sin(pulse * 1.1) * 0.045
	_update_tutorial(zone)


func _update_tutorial(zone: int) -> void:
	if GameEvents.completed:
		if GameEvents.tutorial_stage != 99: GameEvents.set_tutorial(99, "")
		return
	if GameEvents.tutorial_stage < 1 and player.global_position.distance_to($Zones/Entrance/Luma.global_position) < 5.2:
		GameEvents.set_tutorial(1, "Cuando aparezca el aviso, pulsa E para hablar o examinar objetos.")
	elif GameEvents.tutorial_stage < 2 and GameEvents.story_seen.has("luma_intro") and player.global_position.z < -4.0:
		GameEvents.set_tutorial(2, "Un eco bloquea el camino. Pulsa Q cerca de él para emitir un pulso de luz.")
	elif GameEvents.tutorial_stage < 4 and zone == 1:
		GameEvents.set_tutorial(4, "Las runas responden al orden OLA, SOL y ESTRELLA. Si fallas, escucha la pista y vuelve a intentar.")
	elif GameEvents.tutorial_stage < 5 and zone == 2:
		GameEvents.set_tutorial(5, "Espacio para saltar y C para esquivar. La rodada no atraviesa muros: cuidado con los bordes del puente.")
	elif GameEvents.tutorial_stage < 6 and zone == 3:
		GameEvents.set_tutorial(6, "El guardián libera ondas por el suelo. Sáltalas con Espacio, esquiva con C o interrumpe la carga con Q.")


func activate_rune(index: int) -> void:
	if GameEvents.puzzle_solved:
		GameEvents.toast_requested.emit("La melodía del jardín está completa")
		return
	if index != ORDER[rune_progress]:
		rune_progress = 0
		GameEvents.toast_requested.emit("El eco se apaga. El agua debe sonar primero.")
		GameEvents.sound_requested.emit("wrong")
	else:
		rune_progress += 1
		GameEvents.sound_requested.emit("rune")
		GameEvents.toast_requested.emit("Resonancia %d / 3" % rune_progress)
	_refresh_runes()
	if rune_progress == 3:
		GameEvents.puzzle_solved = true
		GameEvents.puzzle_changed.emit(true)
		GameEvents.sound_requested.emit("solved")
		GameEvents.set_objective("Recoge la luz del jardín y asciende al Paso del Cielo")
		GameEvents.toast_requested.emit("El jardín despierta. El camino está abierto.")
		_refresh_gate()
		GameEvents.save_game()


func _refresh_runes() -> void:
	for i in range(3):
		var light: OmniLight3D = get_node("Zones/Puzzle/Resonator_%d/OmniLight3D" % i)
		light.light_color = Color("f9c74f") if ORDER.slice(0,rune_progress).has(i) else Color("4ecdc4")
		light.light_energy = 2.0 if ORDER.slice(0,rune_progress).has(i) else 1.0


func _refresh_gate() -> void:
	gate.visible = not GameEvents.puzzle_solved
	gate.get_node("CollisionShape3D").set_deferred("disabled", GameEvents.puzzle_solved)
	if GameEvents.puzzle_solved:
		rune_progress = 3
		_refresh_runes()
