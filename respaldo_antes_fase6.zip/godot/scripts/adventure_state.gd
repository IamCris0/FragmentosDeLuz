extends Node

signal fragments_changed(collected: int, total: int)
signal energy_changed(current: float, maximum: float)
signal objective_changed(text: String)
signal story_requested(speaker: String, text: String)
signal toast_requested(text: String)
signal puzzle_changed(solved: bool)
signal crystal_activated
signal sound_requested(cue: String)
signal zone_changed(index: int, title: String)
signal tutorial_changed(stage: int, text: String)
signal threat_changed(active_enemies: int)
signal pulse_requested(origin: Vector3, radius: float, force: float)
signal pulse_changed(ratio: float, ready: bool)
signal player_hit(amount: float, reason: String)
signal enemy_purified(enemy_id: StringName, total: int)
signal player_depleted
signal dodge_started(origin: Vector3, direction: Vector3)
signal dodge_changed(ratio: float, ready: bool)
signal guardian_changed(active: bool, integrity: int, state: String)
signal save_status_changed(success: bool, message: String)

const TOTAL: int = 7
const SAVE_PATH: String = "user://fragmentos_save.json"
const SaveStore = preload("res://scripts/save_store.gd")
var collected: int = 0
var fragment_ids: Dictionary = {}
var puzzle_solved: bool = false
var lever_on: bool = false
var completed: bool = false
var checkpoint: Vector3 = Vector3(0, 0.2, 7)
var zone: int = 0
var energy: float = 100.0
var objective: String = "Encuentra a Luma junto al arco antiguo"
var story_seen: Dictionary = {}
var loaded: bool = false
var tutorial_stage: int = 0
var tutorial_text: String = "Mueve a Neri con WASD. Mantén clic derecho para orientar la cámara hacia el arco."
var active_threats: int = 0
var enemies_purified: int = 0
var purified_ids: Dictionary = {}
var damage_grace: float = 0.0
var save_status: String = "El progreso se guarda al avanzar"
var save_error_notified: bool = false


func _physics_process(delta: float) -> void:
	damage_grace = maxf(0.0, damage_grace - delta)


func collect(fragment_id: StringName) -> bool:
	if fragment_ids.has(str(fragment_id)) or collected >= TOTAL:
		return false
	fragment_ids[str(fragment_id)] = true
	collected = fragment_ids.size()
	fragments_changed.emit(collected, TOTAL)
	toast_requested.emit("Fragmento recuperado · %d de %d" % [collected, TOTAL])
	sound_requested.emit("pickup")
	if collected == TOTAL:
		set_objective("Regresa al portal y devuelve la luz a Auralia")
		crystal_activated.emit()
	save_game()
	return true


func set_objective(text: String) -> void:
	objective = text
	objective_changed.emit(text)


func set_energy(value: float) -> void:
	energy = clampf(value, 0.0, 100.0)
	energy_changed.emit(energy, 100.0)


func damage_player(amount: float, reason: String) -> bool:
	if damage_grace > 0.0 or amount <= 0.0:
		return false
	damage_grace = 0.9
	set_energy(energy - amount)
	player_hit.emit(amount, reason)
	toast_requested.emit(reason)
	if energy <= 0.5:
		player_depleted.emit()
	return true


func request_pulse(origin: Vector3, radius: float = 4.6, force: float = 1.55) -> void:
	pulse_requested.emit(origin, radius, force)


func set_pulse_ready(ratio: float, ready: bool) -> void:
	pulse_changed.emit(clampf(ratio, 0.0, 1.0), ready)


func set_threat(count: int) -> void:
	count = max(count, 0)
	if count == active_threats:
		return
	active_threats = count
	threat_changed.emit(active_threats)


func set_tutorial(stage: int, text: String) -> void:
	if stage == tutorial_stage and text == tutorial_text:
		return
	if stage < tutorial_stage and text != "":
		return
	tutorial_stage = max(stage, tutorial_stage)
	tutorial_text = text
	tutorial_changed.emit(tutorial_stage, tutorial_text)
	save_game()


func register_enemy_purified(enemy_id: StringName) -> bool:
	if purified_ids.has(str(enemy_id)):
		return false
	purified_ids[str(enemy_id)] = true
	enemies_purified += 1
	enemy_purified.emit(enemy_id, enemies_purified)
	save_game()
	return true


func story(id: String, speaker: String, text: String) -> void:
	story_seen[id] = true
	story_requested.emit(speaker, text)
	sound_requested.emit("story")
	save_game()


func reset() -> void:
	collected = 0
	fragment_ids.clear()
	puzzle_solved = false
	lever_on = false
	completed = false
	checkpoint = Vector3(0, 0.2, 7)
	zone = 0
	energy = 100.0
	story_seen.clear()
	objective = "Encuentra a Luma junto al arco antiguo"
	tutorial_stage = 0
	tutorial_text = "Mueve a Neri con WASD. Mantén clic derecho para orientar la cámara hacia el arco."
	active_threats = 0
	enemies_purified = 0
	purified_ids.clear()
	damage_grace = 0.0
	loaded = true
	fragments_changed.emit(0, TOTAL)
	energy_changed.emit(energy, 100.0)
	objective_changed.emit(objective)
	threat_changed.emit(0)
	tutorial_changed.emit(0, "Mueve a Neri con WASD. Mantén clic derecho para orientar la cámara hacia el arco.")
	save_game()


func save_game(manual: bool = false) -> bool:
	if "--qa" in OS.get_cmdline_user_args():
		return true
	var error: Error = SaveStore.write_atomic(SAVE_PATH, {"version": 3, "fragments": fragment_ids, "puzzle": puzzle_solved,
		"lever": lever_on, "completed": completed, "checkpoint": [checkpoint.x, checkpoint.y, checkpoint.z],
		"zone": zone, "objective": objective, "story": story_seen, "tutorial": tutorial_stage,
		"tutorial_text": tutorial_text, "enemies_purified": enemies_purified, "purified_ids": purified_ids, "energy": energy})
	if error == OK:
		save_status = "Guardado a las " + Time.get_time_string_from_system()
		save_error_notified = false
	else:
		save_status = "No se pudo guardar. La copia anterior se conserva."
		if not save_error_notified: push_warning("Save failed: " + error_string(error))
		if not save_error_notified or manual: toast_requested.emit(save_status)
		save_error_notified = true
	save_status_changed.emit(error == OK, save_status)
	if manual and error == OK: toast_requested.emit("Partida guardada")
	return error == OK


func load_game() -> void:
	if loaded:
		return
	loaded = true
	if "--qa" in OS.get_cmdline_user_args():
		return
	var result: Dictionary = SaveStore.load_best(SAVE_PATH)
	if result.incompatible:
		save_status = "Partida de una versión posterior: no se sobrescribirá."
		return
	if result.recovered: save_status = "Partida recuperada desde la copia de seguridad"
	var data: Dictionary = result.data
	if data.is_empty(): return
	fragment_ids = data.get("fragments", {})
	collected = mini(fragment_ids.size(), TOTAL)
	puzzle_solved = data.get("puzzle", false)
	lever_on = data.get("lever", false)
	completed = data.get("completed", false)
	zone = clampi(int(data.get("zone", 0)), 0, 3)
	objective = str(data.get("objective", objective))
	story_seen = data.get("story", {})
	tutorial_stage = int(data.get("tutorial", tutorial_stage))
	tutorial_text = str(data.get("tutorial_text", tutorial_text))
	enemies_purified = int(data.get("enemies_purified", 0))
	var saved_ids: Variant = data.get("purified_ids", {})
	purified_ids = saved_ids if saved_ids is Dictionary else {}
	energy = clampf(float(data.get("energy", energy)), 0.0, 100.0)
	if energy <= 0.5: energy = 60.0
	damage_grace = 2.5
	var position_data: Variant = data.get("checkpoint", [0, 0.2, 7])
	if position_data is Array and position_data.size() == 3:
		checkpoint = Vector3(float(position_data[0]), float(position_data[1]), float(position_data[2]))
