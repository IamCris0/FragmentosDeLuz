extends Node3D

var restored: bool = false
var beam: MeshInstance3D
var light: OmniLight3D
var material: ShaderMaterial
var halos: Array[MeshInstance3D] = []
var elapsed: float = 0.0


func _ready() -> void:
	position = Vector3(0, 4.1, -92)
	beam = MeshInstance3D.new()
	beam.name = "BeaconColumn"
	var cylinder := CylinderMesh.new()
	cylinder.top_radius = 0.55
	cylinder.bottom_radius = 1.2
	cylinder.height = 38
	cylinder.radial_segments = 64
	cylinder.cap_top = false
	cylinder.cap_bottom = false
	beam.mesh = cylinder
	beam.position.y = 19
	beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	material = ShaderMaterial.new()
	material.shader = load("res://shaders/beacon.gdshader")
	material.set_shader_parameter("strength", 0.0)
	beam.material_override = material
	add_child(beam)
	light = OmniLight3D.new()
	light.name = "RestoredLight"
	light.light_color = Color("ffe1a6")
	light.omni_range = 16
	light.light_energy = 0
	light.position.y = 5
	add_child(light)
	var glow := StandardMaterial3D.new()
	glow.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	glow.albedo_color = Color("f5d582")
	glow.emission_enabled = true
	glow.emission = Color("ffe5a0")
	glow.emission_energy_multiplier = 1.4
	for i in 2:
		var halo := MeshInstance3D.new()
		halo.name = "RestoredHalo%d" % i
		var ring := TorusMesh.new()
		ring.inner_radius = 1.55 + i * 0.65
		ring.outer_radius = ring.inner_radius + 0.055
		ring.rings = 64
		ring.ring_segments = 8
		halo.mesh = ring
		halo.position.y = 4.0 + i * 2.0
		halo.material_override = glow
		add_child(halo)
		halos.append(halo)
	visible = false
	if GameEvents.completed: restore(false)


func _process(delta: float) -> void:
	if GameEvents.completed and not restored: restore(true)
	if not restored: return
	elapsed += delta
	for i in halos.size():
		halos[i].position.y = 4.0 + i * 2.0 + sin(elapsed * 0.7 + i) * 0.2
		halos[i].rotation.x = sin(elapsed * 0.3 + i) * 0.08


func restore(animate: bool) -> void:
	if restored: return
	restored = true
	visible = true
	var environment: Environment = get_parent().get_node("WorldEnvironment").environment
	if animate:
		GameEvents.sound_requested.emit("beacon_chime")
		var tween := create_tween().set_parallel(true)
		tween.tween_method(func(value: float) -> void: material.set_shader_parameter("strength", value), 0.0, 1.0, 3.0)
		tween.tween_property(light, "light_energy", 3.0, 3.0)
		tween.tween_property(environment, "ambient_light_energy", 0.38, 3.0)
	else:
		material.set_shader_parameter("strength", 1.0)
		light.light_energy = 3.0
		environment.ambient_light_energy = 0.38
