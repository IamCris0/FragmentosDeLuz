# Fragmentos de Luz: El Faro Dormido

Capítulo jugable construido a partir de las referencias visuales y guías recibidas de Miora. Es una aventura 3D estilizada en Godot 4 con assets producidos en Blender, prólogo tipo comic 2D, recorrido de tercera persona, tutorial contextual, enemigos de eco, pulso defensivo, historia, puzzle de runas, ascensor, portal final, HUD, guardado local y audio sintetizado original. Fase 5, validada el 22 de septiembre de 2026: esquiva animada, guardián con ondas de resonancia, música de tensión y restauración visible del faro. Sigue siendo la base del primer capítulo, no una campaña terminada.

## Abrir

Abre `Abrir_demo.cmd`. El lanzador comprueba la importación de los modelos y después abre el juego. Para editarlo, abre `Abrir_editor.cmd` y selecciona `godot/project.godot`.

`Ver_prologo.cmd` permite volver a ver el comic sin borrar tu partida. Las versiones del proyecto comparten el guardado del mismo capítulo; usa Nueva partida desde pausa solamente cuando quieras reiniciarlo.

Esta es la carpeta principal para continuar las siguientes fases: `C:\Users\gcris\OneDrive\Documentos\Proyectos\Game\FragmentosDeLuz`. Las carpetas con nombres de fase son versiones anteriores, no la ubicación de trabajo actual.

## Fase 5: el guardián del faro

Neri puede esquivar con `C`: consume 12 de energía, dura 0,5 segundos y tiene 1,4 segundos de recarga. Los primeros 0,3 segundos protegen del daño. Se inicia desde el suelo, respeta las paredes y usa una animación esquelética de rodada, sonido y una breve estela de polvo. Los diálogos interrumpen inmediatamente el desplazamiento.

El guardián final carga una onda circular con aviso previo. Sus ataques se aceleran al perder cada uno de sus tres núcleos. Puedes saltar la onda, sincronizar la esquiva, cubrirte tras un obstáculo sólido o interrumpir al guardián con `Q`. El HUD muestra su integridad y el estado de la recarga de esquiva. El tutorial introduce estas acciones antes del encuentro final.

El combate incorpora una capa musical adaptativa y cuatro efectos nuevos. Al completar el capítulo se enciende el faro con luz, halos animados y una señal musical; su estado restaurado reaparece al cargar una partida completada. Se corrigió también el bucle musical del prólogo y su advertencia de audio al cerrar la prueba.

Esta fase conserva la forma del personaje de fase 3: añade la rodada y su integración, no un nuevo esculpido de rostro o ropa.

## Fase 4: guardado fiable

El diario incluye Guardar partida y el estado del último guardado. Las escrituras se preparan en un archivo temporal antes de reemplazar la partida, y el guardado anterior válido se conserva en `fragmentos_save.json.bak`. Si el principal falta o está dañado se intenta recuperar esa copia. Las versiones de partida 1 y 2 se migran; una versión posterior a la admitida no se sobrescribe. Si guardar falla, el botón de salida muestra un aviso y mantiene el juego abierto.

La recuperación vuelve a un punto de control seguro. Una partida con energía agotada se reanuda con 60 de energía y una breve protección. Esto protege el progreso local, pero no sustituye un respaldo externo ni resuelve conflictos entre dos instancias abiertas simultáneamente.

## Controles

- `WASD`: mover a Neri.
- `Shift`: correr.
- `Espacio`: saltar.
- `E`: hablar, leer, activar, abrir o recoger.
- `Q`: pulso de luz. Aturde o purifica ecos cercanos y consume energía.
- `C`: esquivar en la dirección de movimiento, o hacia donde mira Neri si está quieto.
- `Esc`: pausar.
- `J` o `F2`: abrir el diario.
- Botón derecho del ratón y arrastrar: girar la cámara.
- Rueda del ratón: ajustar la distancia de cámara.
- Botón de menú inferior: pausa.

## Recorrido del capítulo

1. **Prólogo comic**: cuatro viñetas introducen Auralia, la fractura del faro, Neri y Luma.
2. **Umbral de Auralia**: arco antiguo, Luma, tutorial de movimiento/pulso, dos fragmentos y el primer eco.
3. **Jardín de Resonancia**: tres resonadores, enemigos de eco y el orden correcto `OLA -> SOL -> ESTRELLA`. El cofre entrega el fragmento de la reliquia.
4. **Paso del Cielo**: ascensor, rampa elevada, plataforma de balcón, puente, dos fragmentos y presión de enemigos.
5. **Portal Final**: último fragmento y guardián con tres núcleos y ondas de resonancia. El faro requiere siete fragmentos, puzzle resuelto y guardián purificado; al completarlo se ilumina el santuario.

La secuencia incorrecta reinicia el puzzle. Los fragmentos y la reliquia no se duplican. Hay guardado de progreso en `user://fragmentos_save.json` y guardado manual desde el diario. Los volúmenes y la calidad se conservan por separado en `user://preferences.cfg`. Las pruebas automáticas no modifican estas partidas ni preferencias.

## Sistemas incluidos

- Neri: humanoide Quaternius CC0 adaptado en Blender, 23.397 triángulos, 65 huesos con dedos y pies articulados, once clips derivados de Universal Animation Library, túnica, mochila y escáner. `CharacterBody3D`, `SpringArm3D` y `AnimationTree` para movimiento, cámara, pulso, esquiva y transiciones. El archivo editable es `blender/neri_quaternius.blend`.
- HUD: energía, contador 0/7, objetivo contextual, zona actual, tutorial, medidores de pulso y esquiva, integridad del guardián, amenaza cercana, prompt `[E]`, diálogos de Luma, pausa, diario, volumen y reinicio de partida.
- Enemigos: cinco ecos con patrulla, persecución limitada por suelo y obstáculos, aviso dorado antes de atacar, recuperación, aturdimiento real y purificación persistente. Puedes alejarte del ataque o interrumpirlo con Q. El daño tiene un breve periodo de protección y retrasa la regeneración; agotar la energía devuelve al punto de control. Los diálogos detienen los ataques.
- Mundo: cuatro zonas con nombres, geometría modular, árboles, cristales, columnas, puentes, plataformas y fragmentos coleccionables.
- Interacción: Luma, piedra de memoria, resonadores, cofre de reliquia, palanca, ascensor y portal.
- Presentación: prólogo de cuatro viñetas a pantalla completa con movimiento lento y música, iluminación cálida sobre piedra fría, sombras de mayor precisión, hierba y follaje con viento, estandartes, faroles, motas luminosas, engranajes, cristales flotantes, Luma holográfica, ecos animados y portal animado. Pulso visible en el mundo y señal de daño en los bordes de pantalla.
- Audio: tres variaciones musicales de 64 segundos con transición por zona, capa de tensión de combate de 16 segundos, cascadas y portal con sonido espacial, viento, cuatro variaciones de pasos, aterrizaje, pulso, esquiva, carga/onda del guardián, restauración del faro y efectos de interacción. Música atenuada durante diálogos.
- Ajustes: volumen general, música, ambiente y efectos independientes; calidad gráfica baja, equilibrada y alta desde pausa.

## Estructura

| Carpeta | Contenido |
|---|---|
| `blender/` | Archivos editables de Neri, entorno y métricas de producción. |
| `godot/assets/` | GLB importados, texturas, cielo, interfaz y audio. |
| `godot/assets/story/` | Imagen del prólogo comic. |
| `godot/assets/enemies/` | GLB del eco enemigo. |
| `godot/scenes/` | Escena principal y cuatro zonas. |
| `godot/assets/characters/player.tscn` | Personaje jugable con sus nodos. |
| `godot/assets/ui/hud.tscn` | HUD, pausa, ajustes, diálogo y diario. |
| `godot/scripts/` | Estado global, jugador, interacciones, HUD, audio y plataformas. |
| `godot/shaders/` | Portal, faro restaurado, cascada, barrera, viento de follaje y estandartes. |
| `godot/tools/` | Constructor de mundo y prueba automática del recorrido. |
| `previews/adventure/` | Capturas de entrada, historia, puzzle, paso elevado, portal y HUD estrecho. |
| `referencias/` | Imágenes y textos recibidos como dirección artística. |
| `source_tools/` | Generadores reproducibles de Blender y audio. Ver `DESARROLLO.md`. |
| `source_assets/quaternius/` | Cuerpo, cabello, animaciones y licencias CC0 usados para generar a Neri. |

## Verificación

La validación automática recorre las cuatro zonas, comprueba el prólogo como escena de entrada, el personaje importado, sus 65 huesos y estados de animación, el input de pulso, cinco enemigos, la purificación del eco tutorial, la recogida de los siete fragmentos, el puzzle, la bisagra del cofre, la palanca, el ascensor, las rampas, el guardián como requisito del portal, la pausa, el diario y la recuperación por caída. El informe queda en `previews/adventure/qa_report.json`: 57 comprobaciones superadas en esta fase.

`guardian_report.json` añade 38 comprobaciones de rodada, gasto y recarga, invulnerabilidad temporal, colisiones, salto y cobertura frente a ondas, interrupción, dificultad del guardián, HUD a 800 × 640, bloqueo de diálogos y restauración del faro. `avatar_report.json` comprueba ocho clips en movimiento, incluida la nueva rodada, y el diario estrecho. `prologue_report.json` confirma el cruce real del final del audio hacia el comienzo del bucle.

La prueba adicional de presentación comprueba movimiento visual, vegetación, animación esquelética, salto y aterrizaje, reproducción y bucles musicales, mezcla independiente, fuentes de sonido espacial y ajustes a 1440 × 900 y 800 × 640. Informe: `previews/adventure/polish_report.json`. Las capturas muestran el juego real. No constituyen un análisis de rendimiento prolongado ni validan todas las tarjetas gráficas.

`combat_report.json` cubre aviso, esquiva, interrupción, daño, invulnerabilidad, diálogos, punto de control, persistencia y HUD estrecho. `avatar_report.json` comprueba reproducción y movimiento de los clips importados. `prologue_report.json` comprueba las cuatro viñetas, sus textos y música en dos tamaños de ventana.

`save_report.json` comprueba 22 casos de escritura, recuperación, migración y datos dañados con archivos temporales aislados de tu partida. El diario con sus dos acciones se revisa también a 800 × 640.

## Fuentes y límites

Cuerpo y cabello: [Quaternius Universal Base Characters Standard](https://quaternius.com/packs/universalbasecharacters.html). Animaciones: [Quaternius Universal Animation Library Standard](https://quaternius.com/packs/universalanimationlibrary.html). Ambos son CC0; las licencias originales están en `source_assets/quaternius/`. La base gratuita utilizada es Superhero Male, ajustada de proporciones y vestida para Neri: tiene un aspecto más adulto que la ilustración de Miora. No es una reproducción exacta de esa referencia ni incluye expresiones faciales o apoyo de pies con IK.

El capítulo conserva y amplía la música sintetizada original; esta fase no añade voces ni una banda sonora grabada. Aún quedan por desarrollar nuevos capítulos, mayor variedad de enemigos y una pasada artística manual de ropa y rostro.

La tubería usa Blender 5.2.1 LTS y Godot 4.7.2 Forward+. Godot importa escenas 3D en GLB/glTF y sus nodos de cámara, animación y cuerpos físicos se mantienen editables dentro del proyecto. Referencias: [formatos 3D e importación GLB](https://docs.godotengine.org/en/stable/tutorials/assets_pipeline/importing_3d_scenes/available_formats.html), [SpringArm3D](https://docs.godotengine.org/en/stable/classes/class_springarm3d.html), [AnimationTree](https://docs.godotengine.org/en/stable/tutorials/animation/animation_tree.html), [AnimatableBody3D](https://docs.godotengine.org/en/stable/classes/class_animatablebody3d.html).

Las imágenes de Miora se conservaron como referencias de arte. El cielo, el prólogo comic, la textura de piedra y el marco del medidor se generaron como bitmaps auxiliares para que el capítulo tenga una lectura visual propia y consistente.
