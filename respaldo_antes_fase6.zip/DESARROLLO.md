# Fragmentos de Luz: base de produccion

## Carpeta de trabajo

Continuar todas las siguientes fases directamente en `C:\Users\gcris\OneDrive\Documentos\Proyectos\Game\FragmentosDeLuz`, por peticion del usuario. No trabajar en las entregas versionadas ni volver a copiar encima desde ellas: ahora son instantaneas anteriores. No modificar `SenalPerdida`.

Respaldo del contenido anterior a esta integracion: `C:\Users\gcris\Documents\Codex\Respaldos\FragmentosDeLuz_antes_fase3_20260915`. Incluye escenas, fuentes disponibles y configuracion, sin cache de Godot. Se conservo F2 para el diario y se anadio J como alternativa.

Respaldo previo a fase 5: `C:\Users\gcris\Documents\Codex\Respaldos\FragmentosDeLuz_antes_fase5_20260916`, sin cache de Godot. Implementacion iniciada el 16 y validada el 22 de septiembre de 2026, siempre en la carpeta principal.

## Fase 5: esquiva y guardian

- `player_controller.gd`: accion C, rodada de 0,5 s, coste 12, recarga 1,4 s y proteccion inicial de 0,3 s. Usa `move_and_slide`, no teletransporte. Solo se inicia en suelo; bloquea salto, pulso e interaccion durante la rodada. El bloqueo de dialogo cancela la esquiva y la velocidad horizontal.
- `guardian_sentinel.gd`: especializa el enemigo existente solo para `BeaconEcho`. Avisos de 1,35 / 1,15 / 0,95 s segun integridad; tres nucleos, ondas progresivamente mas rapidas, interrupcion por pulso y purificacion persistente.
- `resonance_wave.gd`: frente anular barrido entre frames, un impacto por onda, exclusion por altura y rayo contra cobertura solida. Permite saltar o atravesar el frente durante la proteccion de una esquiva. Los dialogos cancelan ondas activas.
- `adventure_state.gd`: senales `dodge_started`, `dodge_changed` y `guardian_changed`. No cambia el formato de guardado v3.
- `adventure_hud.gd`: medidor de esquiva y tres marcas de integridad del guardian. El HUD de combate se oculta durante modales y se recoloca a 800 x 640.
- `combat_feedback.gd`: polvo temporal con desvanecimiento durante la rodada; conserva los efectos del pulso.
- `beacon_restoration.gd` y `beacon.gdshader`: columna de luz, halos y aumento de luz ambiental al completar el capitulo. El nodo se crea desde `adventure.gd` y restaura el aspecto inmediatamente al cargar una partida completada.
- `audio_manager.gd`: mezcla gradual de `combat_tension.wav` segun amenaza, con atenuacion durante dialogos. Nuevos efectos `dodge`, `guardian_charge`, `guardian_wave` y `beacon_chime`.

El modelo se regenero con un undecimo clip, `dodge`, derivado de `Roll` de UAL Standard y retimado a 15 frames a 30 fps. La geometria conserva 23.397 triangulos y 65 huesos; no se hizo un nuevo modelado de rostro o ropa en esta fase.

Validacion dedicada: `godot --path .\godot -- --qa --qa-guardian`. El informe exige llegar a la ultima asercion para evitar resultados positivos tras una corrutina interrumpida por error. Supera 38 comprobaciones, incluidas colision de la rodada, salto, cobertura, esquiva sincronizada, cancelacion por dialogo, HUD estrecho y faro restaurado. El recorrido completo mantiene sus 57 comprobaciones superadas. Los fixtures trasladan temporalmente al guardian al umbral para aislar las pruebas; en el juego sigue situado en PortalFinal.

## Fase 4: progreso fiable

`scripts/save_store.gd` encapsula validacion, migracion y escritura temporal con reemplazo final. Solo una partida anterior valida se rota a `.bak`. Se recupera desde esa copia si el archivo principal falta o es invalido, y se impide sobrescribir versiones futuras. `GameEvents.save_game()` devuelve resultado y emite estado; el diario permite guardado manual. Salir desde pausa no cierra el juego si guardar falla.

Los identificadores del capitulo y puntos de control se validan expresamente. Al agregar capitulos, ampliar esa tabla o sustituirla por datos de cada nivel con una migracion versionada. El almacenamiento actual no es un sistema de sincronizacion entre procesos: evitar ejecutar dos versiones contra la misma partida a la vez. OneDrive contiene el proyecto, pero Godot guarda la partida en AppData local.

Prueba aislada: `godot --headless --path .\godot --script res://tools/qa_save_store.gd -- --qa`. Cubre 22 casos, incluyendo archivos incompletos, respaldo recuperable, versiones antiguas/futuras, tipos incorrectos y destino no escribible. No modifica la partida real.

Resuelto en fase 5: el prologo utiliza el recurso de audio importado sin duplicarlo en ejecucion y configura `edit/loop_mode=2` (Forward) en su `.wav.import`. La prueba comprueba reproduccion al cruzar el limite final del archivo, ademas de las cuatro vinetas a 1440 x 900 y 800 x 640. El cierre final validado no presenta las anteriores referencias de audio no liberadas.

## Alcance del pulido

Fase 3, 2026-09-15. Esta entrega conserva el primer capitulo de cuatro zonas e integra un cuerpo humanoide externo CC0, diez clips retargeteados, combate con aviso/interrupcion y un prologo que presenta cada vineta por separado con movimiento y musica. Corrige enemigos inactivos por el orden de carga, aturdimiento, dano acumulado, regeneracion inmediata, repeticion de guardados del tutorial y continuidad de dialogos. Conserva follaje, audio sintetizado, mecanismos, HUD y contenido de las fases anteriores. No incluye voces grabadas, nuevos capitulos, combate avanzado con combos ni animacion facial.

Neri usa Superhero Male y Hair SimpleParted del paquete gratuito Quaternius Universal Base Characters Standard. Se ajustaron proporciones, materiales, ropa y accesorios en Blender, conservando 65 huesos. La salida contiene una malla, diez superficies de material y 23.397 triangulos. Se eliminaron caras ocultas bajo la ropa y se recalcularon normales; las prendas usan una sola superficie para evitar capas casi coincidentes. Los bordes de mangas se recortan por planos y el faldon tiene pesos de muslo/pelvis. Es una interpretacion mas adulta que la hoja de Miora. La siguiente pasada artistica puede centrarse en ropa hecha a medida, rostro, expresiones y apoyo de pies con IK.

## Nodos principales

- `GameEvents`: autoload de `scripts/adventure_state.gd`, progreso, objetivos, senales y guardado.
- `Preferences`: autoload con buses de volumen, calidad y persistencia independiente.
- `PrologueComic`: escena inicial `scenes/prologue_comic.tscn`; muestra el comic 2D y luego cambia a `main_island.tscn`.
- `Player`: `CharacterBody3D`, colision, modelo GLB con `Skeleton3D` y `AnimationPlayer`, `AnimationTree`, pivote de camara, `SpringArm3D` y pulso defensivo con `Q`.
- `EnemySentinel`: `Area3D` con estados de patrulla, persecucion, aviso, recuperacion y aturdimiento. Busca al jugador despues de la carga y comprueba suelo, obstaculos, altura y linea de vision. Los identificadores de purificacion quedan en el guardado v3. Las partidas anteriores se pueden leer, aunque no contienen esos identificadores individuales.
- `BeaconEcho`: utiliza `guardian_sentinel.gd`; crea `ResonanceWave` durante su ataque. El resto de ecos mantiene su comportamiento de corta distancia.
- `BeaconRestoration`: nodo de la escena principal, con `BeaconColumn`, `RestoredLight` y dos halos animados.
- `CombatFeedback`: anillos y luz de pulso temporales. El HUD usa `damage_edge.gdshader` para mostrar dano sin tapar el centro.
- `Zones`: Entrance, Puzzle, Elevated y PortalFinal. Cada zona conserva su escena editable.
- `EnvironmentLife`: aplica materiales animados a las superficies importadas, configura la calidad y anima detalles ambientales.
- `AudioManager`: tres reproductores musicales sincronizados, viento, voces de efectos y `AudioStreamPlayer3D` para cascadas y portal.
- HUD: `CanvasLayer` con `TextureProgressBar`, contador, objetivo, tutorial, pulso, amenaza, interaccion, dialogos, diario, pausa y ajustes.

## Regenerar sin perder trabajo

Los archivos `.blend`, `.glb`, `.tscn`, shaders y scripts se entregan editables. Antes de ejecutar generadores, guarda una copia: regeneran recursos con nombres existentes. Los cambios manuales de las escenas generadas no se conservan automaticamente. Para ampliar niveles sin ese riesgo, crea escenas adicionales e instancialas desde una escena propia, o incorpora el cambio al generador de forma deliberada.

Desde la raiz de esta carpeta, usando Blender 5.2.1 y Godot 4.7.2:

```powershell
& 'C:\Program Files\Blender Foundation\Blender 5.2\blender.exe' --background --factory-startup --python .\source_tools\build_adventure_assets.py
& 'C:\Program Files\Blender Foundation\Blender 5.2\blender.exe' --background --factory-startup --python .\source_tools\build_neri_quaternius.py
& 'C:\Users\gcris\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' .\source_tools\build_audio.py
& 'C:\Users\gcris\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' .\source_tools\build_audio_polish.py
& 'C:\Users\gcris\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe' .\source_tools\build_combat_audio.py
# Con el ejecutable de Godot disponible como godot:
godot --headless --editor --path .\godot --import --quit
godot --headless --path .\godot --script res://tools/build_world.gd
godot --path .\godot -- --qa
godot --path .\godot -- --qa --qa-polish
godot --path .\godot -- --qa --qa-combat
godot --path .\godot -- --qa --qa-guardian
godot --path .\godot -- --qa --qa-avatar
godot --path .\godot -- --qa --qa-prologue
godot --headless --path .\godot --script res://tools/qa_save_store.gd -- --qa
```

El generador de Neri lee `source_assets/quaternius/`, sin necesitar red, y produce `blender/neri_quaternius.blend`, sus metricas y `godot/assets/characters/neri_quaternius.glb`. Si solo editas a Neri no hace falta reconstruir el entorno ni el audio. El antiguo `adventurer.glb` se conserva porque Luma aun lo utiliza como holograma. El generador de audio original debe ejecutarse antes del de pulido. Las pruebas visuales necesitan una ventana grafica; no usar `--headless` con ellas. Las pruebas usan entradas de movimiento y colisiones reales, pero no sustituyen sesiones manuales largas. Los archivos de informe indican cada comprobacion y cualquier fallo.

Los clips idle, walk, run, jump, fall, land, interact, wave, pulse, hurt y dodge se derivan de UAL Standard. El nombre interno wave corresponde a Idle_Talking_Loop, un gesto conversacional, no a un saludo de mano. Se omite desplazamiento global del esqueleto para que CharacterBody3D controle el movimiento y se ajusta la duracion de las acciones a los tiempos del controlador.

`build_combat_audio.py` sintetiza cinco WAV originales con NumPy y semilla reproducible: esquiva (0,5 s), carga (1,35 s), onda (1,1 s), faro (4 s) y tension (16 s en bucle). Escribe metricas en `blender/combat_audio_metrics.json`. Los efectos no necesitan fuentes externas ni claves de servicios.

El prologo se puede repetir con `Ver_prologo.cmd` o `godot --path .\godot -- --replay-prologue`. No borra la partida.

## Datos locales y rendimiento

Partida: `user://fragmentos_save.json`. Preferencias: `user://preferences.cfg`. En Windows, Godot guarda estos datos bajo `%APPDATA%\Godot\app_userdata\Fragmentos de Luz - El Faro Dormido`. Los modos de prueba omiten la persistencia del usuario.

Calidad baja reduce resolucion 3D, particulas y sombras; los otros perfiles permiten priorizar detalle. El capitulo se verifico en Windows con renderizado Forward+ y la GPU disponible, no en dispositivos moviles. El contador de FPS al final de un informe es una muestra puntual, no una garantia de rendimiento.

Antes de ampliar el mapa: medir llamadas de dibujo y tiempos de GPU durante un recorrido prolongado, consolidar superficies estaticas, definir presupuesto por zona y probar guardado y carga entre futuros capitulos. Mantener las interfaces actuales de senales evita acoplar el HUD a cada nivel.

## Registro de bitmaps de fases anteriores

Herramienta: skill `imagegen` con el generador integrado.

Assets conservados:

- `godot/assets/environment/stone_painted.png`: textura raster de piedra usada en el nivel. Archivo original de la sesion anterior: `C:\Users\gcris\.codex\generated_images\01a098f8-db8d-7530-8fff-23531933a26f\exec-1df7ac17-756f-4042-8a48-9164d5c8ee84.png`.
- `godot/assets/story/prologue_comic.png`: comic 2D de cuatro vinetas para el arranque. Archivo original de esta sesion: `C:\Users\gcris\.codex\generated_images\01a098f8-db8d-7530-8fff-23531933a26f\call_I36zGvMUQvFdCTGxu2C9CiZN.png`.

Prompt enviado:

> Use case: stylized-concept. Asset type: seamless square albedo texture for a 3D fantasy adventure's ancient stone pathways. Orthographic top-down surface fills every pixel, no perspective, no border. A continuous fine-grained cool grey-green weathered limestone surface, hand-painted animation-film style with broad subtle painterly tonal variation, occasional small angular cracks, very sparse moss along cracks. No separate paving blocks, no grid, no deep black gaps, no repeated symbols, no text. Medium-dark stone with restrained teal moss, low contrast, no directional lighting or cast shadows, no photo realism, no fine noisy grain. Seamlessly tileable horizontally and vertically. Texture only, no rendered object. Square bitmap.

Se inspecciono el resultado aplicado al pavimento dentro de Godot. El arte recibido de Miora permanece como referencia; no son modelos 3D importables por si solos. Los generadores locales producen los props y el audio, y adaptan el cuerpo externo de Neri.

Prompt del prologo:

> Use case: illustration-story. Asset type: 2D prologue comic splash for a Godot fantasy adventure game. Primary request: a four-panel horizontal comic page introducing Fragmentos de Luz, with no written text inside the image. Scene/backdrop: floating ancient island city above clouds, broken lighthouse beacon, teal energy crystals, golden dusk, purple storm haze. Subject: Panel 1 shows Auralia floating peacefully with a bright lighthouse; Panel 2 shows the beacon shattering into seven golden fragments; Panel 3 shows young adventurer Neri with short brown hair, blue tunic, small green canvas backpack, wrist crystal scanner, discovering a signal map; Panel 4 shows Neri arriving through an ancient stone arch as a small teal holographic guide waits. Style/medium: polished 2D comic illustration, stylized fantasy adventure, clean readable silhouettes, soft painterly shading, consistent teal-gold-purple palette. Composition/framing: 16:9 landscape page divided into four cinematic comic panels with clear gutters, each panel readable at game intro size. Lighting/mood: hopeful but mysterious, dramatic volumetric sky light, glowing teal crystals, warm gold highlights. Color palette: teal, antique gold, indigo, soft purple storm clouds, cool stone. Constraints: no text, no logos, no watermark, no speech bubbles, no UI elements; Neri must match the existing reference concept: short tunic, slim trousers, ankle boots, small backpack, wrist scanner.

## Assets externos revisados

Se verifico el paquete KayKit Character Pack: Adventurers desde la libreria de Godot/GitHub. Tiene licencia CC0, personajes riggeados y muchas animaciones, pero su estetica sigue siendo low-poly por piezas; por eso no se sustituyo a Neri en esta fase. Queda descargado para inspeccion local en `C:\Users\gcris\Documents\Codex\kaykit_adventurers_inspect_20260914`.

En fase 3 se incorporaron [Universal Base Characters Standard](https://quaternius.com/packs/universalbasecharacters.html) y [Universal Animation Library Standard](https://quaternius.com/packs/universalanimationlibrary.html), ambos de Quaternius con licencia CC0. Las fuentes utilizadas y las licencias originales estan incluidas en `source_assets/quaternius/`. No se usaron los cuerpos regular/teen de paquetes de pago ni assets sin licencia verificada.

## Documentacion de referencia

La configuracion ambiental y los efectos se apoyan en la [documentacion de entorno y posprocesado de Godot](https://docs.godotengine.org/en/stable/tutorials/3d/environment_and_post_processing.html). Las fuentes locales usan [AudioStreamPlayer3D](https://docs.godotengine.org/en/stable/classes/class_audiostreamplayer3d.html) para la atenuacion espacial. Estos enlaces describen las funciones del motor, no certifican la calidad artistica ni el rendimiento de este proyecto.

Se ajustaron SSAO, distancia de sombras y sesgo del sol; se usa profundidad de sombras de 32 bits y filtrado medio para reducir ruido en ropa y accesorios. Referencia: [luces y sombras](https://docs.godotengine.org/en/stable/tutorials/3d/lights_and_shadows.html). La calidad baja sigue desactivando sombras. Las capturas de control se realizaron con sombras activadas; los argumentos internos de diagnostico `--qa-no-shadows`, `--qa-no-sun-shadow` y `--qa-no-ssao` no forman parte del arranque normal.
